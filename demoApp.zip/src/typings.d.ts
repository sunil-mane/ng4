/* SystemJS module definition */
declare var module: NodeModule;
declare var $;
interface NodeModule {
  id: string;
}
