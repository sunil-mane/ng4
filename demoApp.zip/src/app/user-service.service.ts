import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import 'rxjs/Rx';

@Injectable()
export class UserServiceService {

  public baseApi = 'https://jsonplaceholder.typicode.com/';
  constructor(private http: Http) { }

  public getUsers() {
    return this.http.get( this.baseApi + 'users').map(response => response.json());
  }

}
