import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit, OnChanges {

  @Input() cname;
  @Output() update= new EventEmitter();

  public countries: any[];
  public selectedCountry: any;

  constructor() { }

  ngOnInit() {
    this.countries = [
      { two_letter: 'IN', name: 'India' },
      { two_letter: 'GB', name: 'Great Britain' },
      { two_letter: 'US', name: 'USA' },
      { two_letter: 'BE', name: 'Belgium' }
    ];

    this.selectedCountry = this.countries[2];
  }

  public changeTitle() {
    this.update.emit('New title from child');
  }

  public ngOnChanges() {
    console.log('name property is changed..');
  }

}
