import { Component, OnInit, OnDestroy, OnChanges } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy, OnChanges {
  public title = 'App Works!';
  public today = new Date();
  public name = 'Sunil Mane';
  constructor() {
    console.log('constructor called');
  }

  ngOnInit() {
    console.log('init called');
    $('#demo').html('abc');
  }

  ngOnDestroy() {
    console.log('destroy called');
  }

  ngOnChanges() {
    console.log('something changed');
  }

  public clicked() {
    alert('Hiiii');
  }

  public updateTitle(message: string) {
    this.title = message;
  }

}
